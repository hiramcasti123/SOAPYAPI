# API SOAP - Sistema de Encuestas

## Descripción del Proyecto

Esta API SOAP ha sido desarrollada usando **Spring Boot** y **Spring Web Services** para manejar un sistema de encuestas completo con operaciones CRUD para preguntas y respuestas.

## Características Principales

- ✅ **Arquitectura Orientada a Servicios (SOA)** con SOAP/XML
- ✅ **Esquema XSD** bien definido para validación de mensajes
- ✅ **WSDL** generado automáticamente
- ✅ **CRUD completo** para Preguntas y Respuestas
- ✅ **Base de datos MySQL** con JPA/Hibernate
- ✅ **Validación de datos** con XML Schema
- ✅ **Manejo de errores** estructurado

## Entidades del Sistema

### Question (Pregunta)
- `id`: Identificador único
- `surveyId`: ID de la encuesta a la que pertenece
- `text`: Texto de la pregunta
- `type`: Tipo de pregunta (TEXT, MULTIPLE_CHOICE, SINGLE_CHOICE, RATING)
- `isRequired`: Indica si es obligatoria
- `options`: Lista de opciones (para preguntas de selección)
- `createdAt`: Fecha de creación
- `updatedAt`: Fecha de última actualización

### Answer (Respuesta)
- `id`: Identificador único
- `questionId`: ID de la pregunta respondida
- `userId`: ID del usuario que responde
- `answerText`: Texto de respuesta libre
- `selectedOption`: Opción seleccionada
- `rating`: Calificación numérica
- `submittedAt`: Fecha de envío

## Operaciones SOAP Disponibles

### Operaciones de Preguntas

1. **getQuestion** - Obtener pregunta por ID
2. **getQuestionsBySurvey** - Obtener todas las preguntas de una encuesta
3. **addQuestion** - Crear nueva pregunta
4. **updateQuestion** - Actualizar pregunta existente
5. **deleteQuestion** - Eliminar pregunta

### Operaciones de Respuestas

1. **getAnswer** - Obtener respuesta por ID
2. **getAnswersByQuestion** - Obtener todas las respuestas a una pregunta
3. **getAnswersByUser** - Obtener respuestas de un usuario
4. **addAnswer** - Crear nueva respuesta
5. **updateAnswer** - Actualizar respuesta existente
6. **deleteAnswer** - Eliminar respuesta

## 📁 Archivos Importantes

- **`README.md`** - Esta documentación completa
- **`GUIA-RAPIDA.md`** - Guía de inicio rápido
- **`setup-database.sql`** - Script para configurar MySQL
- **`application.properties.example`** - Configuración de ejemplo
- **`ejemplos-soap/`** - Ejemplos de peticiones SOAP listas para usar

## Configuración de la Base de Datos

### 1. Crear la Base de Datos MySQL

```sql
CREATE DATABASE survey_db;
USE survey_db;
```

### 2. Configurar application.properties

El archivo ya está configurado con las siguientes propiedades:

```properties
# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/survey_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA/Hibernate Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect
```

**Nota:** Cambia `username` y `password` según tu configuración de MySQL.

## Iniciar la Aplicación

### 1. Compilar el proyecto
```bash
mvn clean compile
```

### 2. Ejecutar la aplicación
```bash
mvn spring-boot:run
```

La aplicación se ejecutará en `http://localhost:8080`

## Endpoints Importantes

- **WSDL**: `http://localhost:8080/ws/survey.wsdl`
- **Endpoint SOAP**: `http://localhost:8080/ws`

## Estructura del Proyecto

```
src/
├── main/
│   ├── java/
│   │   └── com/example/soap/
│   │       ├── SoapApplication.java          # Clase principal
│   │       ├── config/
│   │       │   └── WebServiceConfig.java     # Configuración SOAP
│   │       ├── entity/
│   │       │   ├── QuestionEntity.java       # Entidad Question
│   │       │   ├── AnswerEntity.java         # Entidad Answer
│   │       │   └── QuestionTypeEnum.java     # Enum tipos de pregunta
│   │       ├── repository/
│   │       │   ├── QuestionRepository.java   # Repositorio Question
│   │       │   └── AnswerRepository.java     # Repositorio Answer
│   │       ├── service/
│   │       │   ├── QuestionService.java      # Servicio Question
│   │       │   └── AnswerService.java        # Servicio Answer
│   │       └── endpoint/
│   │           ├── QuestionEndpoint.java     # Endpoint SOAP Question
│   │           └── AnswerEndpoint.java       # Endpoint SOAP Answer
│   └── resources/
│       ├── schemas/
│       │   └── survey.xsd                    # Esquema XML
│       └── application.properties            # Configuración
└── target/
    └── generated-sources/jaxb/               # Clases JAXB generadas
```

## Ejemplo de Uso con SoapUI o Cliente SOAP

### 1. Crear una pregunta

```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addQuestionRequest>
         <sur:question>
            <sur:surveyId>1</sur:surveyId>
            <sur:text>¿Cuál es tu color favorito?</sur:text>
            <sur:type>MULTIPLE_CHOICE</sur:type>
            <sur:isRequired>true</sur:isRequired>
            <sur:options>Rojo</sur:options>
            <sur:options>Azul</sur:options>
            <sur:options>Verde</sur:options>
         </sur:question>
      </sur:addQuestionRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

### 2. Crear una respuesta

```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addAnswerRequest>
         <sur:answer>
            <sur:questionId>1</sur:questionId>
            <sur:userId>100</sur:userId>
            <sur:selectedOption>Azul</sur:selectedOption>
         </sur:answer>
      </sur:addAnswerRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

## Tecnologías Utilizadas

- **Spring Boot 3.5.7**
- **Spring Web Services**
- **Spring Data JPA**
- **MySQL 8.0**
- **JAXB** (Java Architecture for XML Binding)
- **Maven** para gestión de dependencias

## Validación y Pruebas

El proyecto incluye:
- ✅ Validación automática con XSD
- ✅ Manejo de excepciones
- ✅ Conversión automática entre objetos JAXB y entidades JPA
- ✅ Transacciones de base de datos

## Notas Importantes

1. **Namespace**: Todas las operaciones SOAP usan el namespace `http://soap.example.com/survey`
2. **Validación**: Los mensajes XML se validan automáticamente contra el esquema XSD
3. **Transacciones**: Los servicios están anotados con `@Transactional`
4. **Fechas**: Se manejan automáticamente con `LocalDateTime` y se convierten a `XMLGregorianCalendar` para SOAP

## Troubleshooting

### Error de conexión a MySQL
- Verifica que MySQL esté ejecutándose
- Confirma las credenciales en `application.properties`
- Asegúrate de que la base de datos `survey_db` exista

### Error de compilación JAXB
- Ejecuta `mvn clean` antes de `mvn compile`
- Verifica que el directorio `schemas/` contenga el archivo `survey.xsd`

### WSDL no se genera
- Confirma que la aplicación esté ejecutándose
- Accede a `http://localhost:8080/ws/survey.wsdl`
- Revisa los logs para errores de configuración

## Autor

Desarrollado como parte del Reto de Arquitectura Orientada a Servicios (SOA).