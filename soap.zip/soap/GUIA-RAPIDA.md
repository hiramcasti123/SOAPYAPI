# Guía Rápida de Uso - API SOAP para Sistema de Encuestas

## 🚀 Inicio Rápido

### ✅ **Con Railway (Recomendado - Sin configuración local)**
```bash
# Solo necesitas estos pasos:

# Paso 1: Copiar configuración de Railway
cp application.properties.example src/main/resources/application.properties

# Paso 2: Compilar y ejecutar
mvn clean compile
mvn spring-boot:run
```

### 🏠 **Con MySQL Local (Opcional)**
```bash
# Conectar a MySQL local
mysql -u root -p

# Ejecutar el script de configuración
source setup-database.sql
```

### Configurar aplicación local
```bash
# Editar manualmente las credenciales para MySQL local
nano src/main/resources/application.properties
```

---

### ✅ **Verificar que funciona**
- **WSDL**: http://localhost:8080/ws/survey.wsdl
- **Endpoint SOAP**: http://localhost:8080/ws

---

## 🧪 Probar con Postman (⭐ RECOMENDADO)

### Configuración Inicial en Postman

1. **Crear nueva colección** llamada "SOAP Survey API"
2. **Configurar variables de entorno**:
   - `baseUrl`: `http://localhost:8080`
   - `soapEndpoint`: `{{baseUrl}}/ws`

### Configuración de Request Base

Para **TODAS** las peticiones SOAP en Postman:

**Método**: `POST`
**URL**: `{{soapEndpoint}}` o `http://localhost:8080/ws`

**Headers necesarios**:
```
Content-Type: text/xml; charset=utf-8
SOAPAction: ""
Accept: text/xml
```

### 📋 Ejemplos Listos para Postman

#### 1. ✅ **Crear Pregunta de Selección Múltiple**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addQuestionRequest>
         <sur:question>
            <sur:surveyId>1</sur:surveyId>
            <sur:text>¿Cuál es tu color favorito?</sur:text>
            <sur:type>MULTIPLE_CHOICE</sur:type>
            <sur:isRequired>true</sur:isRequired>
            <sur:options>Rojo</sur:options>
            <sur:options>Azul</sur:options>
            <sur:options>Verde</sur:options>
            <sur:options>Amarillo</sur:options>
         </sur:question>
      </sur:addQuestionRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

#### 2. ✅ **Crear Pregunta de Texto**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addQuestionRequest>
         <sur:question>
            <sur:surveyId>1</sur:surveyId>
            <sur:text>¿Qué opinas sobre nuestro servicio?</sur:text>
            <sur:type>TEXT</sur:type>
            <sur:isRequired>true</sur:isRequired>
         </sur:question>
      </sur:addQuestionRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

#### 3. ✅ **Obtener Todas las Preguntas de una Encuesta**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:getQuestionsBySurveyRequest>
         <sur:surveyId>1</sur:surveyId>
      </sur:getQuestionsBySurveyRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

#### 4. ✅ **Crear Respuesta de Selección**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addAnswerRequest>
         <sur:answer>
            <sur:questionId>1</sur:questionId>
            <sur:userId>100</sur:userId>
            <sur:selectedOption>Azul</sur:selectedOption>
         </sur:answer>
      </sur:addAnswerRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

#### 5. ✅ **Crear Respuesta de Texto**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:addAnswerRequest>
         <sur:answer>
            <sur:questionId>2</sur:questionId>
            <sur:userId>100</sur:userId>
            <sur:answerText>El servicio es excelente y muy rápido</sur:answerText>
         </sur:answer>
      </sur:addAnswerRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

#### 6. ✅ **Ver Respuestas de un Usuario**
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
                  xmlns:sur="http://soap.example.com/survey">
   <soapenv:Header/>
   <soapenv:Body>
      <sur:getAnswersByUserRequest>
         <sur:userId>100</sur:userId>
         <sur:surveyId>1</sur:surveyId>
      </sur:getAnswersByUserRequest>
   </soapenv:Body>
</soapenv:Envelope>
```

### 🎯 **Flujo de Prueba en Postman**

1. **Ejecutar aplicación**:
   ```bash
   mvn spring-boot:run
   ```

2. **En Postman**:
   - Crear request con POST a `http://localhost:8080/ws`
   - Agregar headers requeridos
   - Copiar cualquiera de los XMLs de arriba al Body (raw/XML)
   - Send!

### 📊 **Respuestas Esperadas**

**Éxito al crear pregunta**:
```xml
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
   <soap:Body>
      <ns2:addQuestionResponse xmlns:ns2="http://soap.example.com/survey">
         <ns2:question>
            <ns2:id>1</ns2:id>
            <ns2:surveyId>1</ns2:surveyId>
            <ns2:text>¿Cuál es tu color favorito?</ns2:text>
            <ns2:type>MULTIPLE_CHOICE</ns2:type>
            <ns2:isRequired>true</ns2:isRequired>
            <ns2:options>Rojo</ns2:options>
            <ns2:options>Azul</ns2:options>
            <!-- ... más opciones ... -->
         </ns2:question>
         <ns2:success>true</ns2:success>
         <ns2:message>Pregunta creada exitosamente</ns2:message>
      </ns2:addQuestionResponse>
   </soap:Body>
</soap:Envelope>
```

### Usando curl (línea de comandos)

```bash
# Crear una pregunta
curl -X POST \
  http://localhost:8080/ws \
  -H 'Content-Type: text/xml; charset=utf-8' \
  -H 'SOAPAction: ""' \
  -d @ejemplos-soap/1-add-question.xml

# Obtener preguntas de una encuesta
curl -X POST \
  http://localhost:8080/ws \
  -H 'Content-Type: text/xml; charset=utf-8' \
  -H 'SOAPAction: ""' \
  -d @ejemplos-soap/5-get-questions-by-survey.xml
```

### Usando SoapUI

1. **Crear nuevo proyecto SOAP**
2. **WSDL URL**: `http://localhost:8080/ws/survey.wsdl`
3. **Usar los ejemplos XML** de la carpeta `ejemplos-soap/`

---

## 📋 Flujo de Prueba Recomendado

### 1. Crear Preguntas
```bash
# Pregunta de selección múltiple
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/1-add-question.xml

# Pregunta de texto libre
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/2-add-text-question.xml

# Pregunta de calificación
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/3-add-rating-question.xml
```

### 2. Consultar Preguntas
```bash
# Ver todas las preguntas de la encuesta 1
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/5-get-questions-by-survey.xml
```

### 3. Crear Respuestas
```bash
# Respuesta a pregunta de selección múltiple
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/6-add-answer-multiple-choice.xml

# Respuesta de texto
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/7-add-answer-text.xml

# Respuesta de calificación
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/8-add-answer-rating.xml
```

### 4. Consultar Respuestas
```bash
# Ver respuestas por pregunta
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/9-get-answers-by-question.xml

# Ver respuestas por usuario
curl -X POST http://localhost:8080/ws -H 'Content-Type: text/xml' -H 'SOAPAction: ""' -d @ejemplos-soap/10-get-answers-by-user.xml
```

---

## 🔧 Personalización de Ejemplos

### Modificar IDs
En los archivos XML, ajusta estos valores según tus datos:
- `<sur:surveyId>`: ID de la encuesta
- `<sur:questionId>`: ID de la pregunta 
- `<sur:userId>`: ID del usuario
- `<sur:id>`: ID del registro a consultar

### Tipos de Preguntas Disponibles
- `TEXT`: Respuesta de texto libre
- `MULTIPLE_CHOICE`: Selección múltiple
- `SINGLE_CHOICE`: Selección única
- `RATING`: Calificación numérica

---

## 📊 Verificar Datos en MySQL

```sql
-- Ver todas las preguntas
SELECT * FROM questions;

-- Ver opciones de preguntas
SELECT * FROM question_options;

-- Ver todas las respuestas
SELECT * FROM answers;

-- Ver respuestas completas con información de pregunta
SELECT 
    q.text as pregunta,
    q.type as tipo_pregunta,
    a.user_id,
    a.answer_text,
    a.selected_option,
    a.rating,
    a.submitted_at
FROM questions q 
LEFT JOIN answers a ON q.id = a.question_id
ORDER BY q.id, a.user_id;
```

---

## 🚨 Troubleshooting Común

### 🚨 Troubleshooting con Postman

#### ❌ **Error: "Could not get response"**
- Verificar que la aplicación esté ejecutándose (`mvn spring-boot:run`)
- Confirmar URL: `http://localhost:8080/ws`

#### ❌ **Error 500: Internal Server Error**
- Revisar que los IDs en el XML existan (ej: questionId, surveyId)
- Verificar conexión a Railway MySQL en los logs

#### ❌ **Error: "Content type 'application/xml' not supported"**
- Cambiar header a: `Content-Type: text/xml; charset=utf-8`

#### ✅ **Tips para Postman**
1. **Guardar requests** en una colección para reutilizar
2. **Usar variables** para IDs que cambien ({{questionId}})
3. **Verificar Pre-request Scripts** si usas autenticación
4. **Revisar Response** en formato XML para mejor lectura

### Error de conexión a MySQL Railway
```bash
# Verificar logs de aplicación para errores de Railway
mvn spring-boot:run

# Buscar en logs:
# "Access denied" = credenciales incorrectas
# "Connection refused" = Railway no accesible
```

### Puerto 8080 ocupado
Cambiar puerto en `application.properties`:
```properties
server.port=8081
```

### Error WSDL no encontrado
Esperar que la aplicación termine de cargar completamente antes de acceder al WSDL.

### Logs para debugging
Ver logs en tiempo real:
```bash
tail -f logs/spring.log
```

O aumentar nivel de logging en `application.properties`:
```properties
logging.level.org.springframework.ws=DEBUG
logging.level.com.example.soap=DEBUG
```