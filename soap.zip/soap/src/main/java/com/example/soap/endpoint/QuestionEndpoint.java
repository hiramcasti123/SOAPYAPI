package com.example.soap.endpoint;

import com.example.soap.entity.QuestionEntity;
import com.example.soap.generated.*;
import com.example.soap.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import java.util.Optional;

@Endpoint
public class QuestionEndpoint {
    
    private static final String NAMESPACE_URI = "http://soap.example.com/survey";
    
    private final QuestionService questionService;
    
    @Autowired
    public QuestionEndpoint(QuestionService questionService) {
        this.questionService = questionService;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getQuestionRequest")
    @ResponsePayload
    public GetQuestionResponse getQuestion(@RequestPayload GetQuestionRequest request) {
        GetQuestionResponse response = new GetQuestionResponse();
        
        Optional<QuestionEntity> questionOpt = questionService.findById(request.getId());
        if (questionOpt.isPresent()) {
            Question question = questionService.convertToJaxb(questionOpt.get());
            response.setQuestion(question);
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getQuestionsBySurveyRequest")
    @ResponsePayload
    public GetQuestionsBySurveyResponse getQuestionsBySurvey(@RequestPayload GetQuestionsBySurveyRequest request) {
        GetQuestionsBySurveyResponse response = new GetQuestionsBySurveyResponse();
        
        java.util.List<QuestionEntity> questions = questionService.findBySurveyId(request.getSurveyId());
        for (QuestionEntity entity : questions) {
            Question question = questionService.convertToJaxb(entity);
            response.getQuestions().add(question);
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "addQuestionRequest")
    @ResponsePayload
    public AddQuestionResponse addQuestion(@RequestPayload AddQuestionRequest request) {
        AddQuestionResponse response = new AddQuestionResponse();
        
        try {
            QuestionEntity entity = questionService.convertToEntity(request.getQuestion());
            QuestionEntity savedEntity = questionService.save(entity);
            
            Question savedQuestion = questionService.convertToJaxb(savedEntity);
            response.setQuestion(savedQuestion);
            response.setSuccess(true);
            response.setMessage("Pregunta creada exitosamente");
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al crear la pregunta: " + e.getMessage());
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "updateQuestionRequest")
    @ResponsePayload
    public UpdateQuestionResponse updateQuestion(@RequestPayload UpdateQuestionRequest request) {
        UpdateQuestionResponse response = new UpdateQuestionResponse();
        
        try {
            QuestionEntity entity = questionService.convertToEntity(request.getQuestion());
            
            if (entity.getId() == null || !questionService.findById(entity.getId()).isPresent()) {
                response.setSuccess(false);
                response.setMessage("Pregunta no encontrada");
                return response;
            }
            
            QuestionEntity savedEntity = questionService.save(entity);
            Question savedQuestion = questionService.convertToJaxb(savedEntity);
            
            response.setQuestion(savedQuestion);
            response.setSuccess(true);
            response.setMessage("Pregunta actualizada exitosamente");
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al actualizar la pregunta: " + e.getMessage());
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "deleteQuestionRequest")
    @ResponsePayload
    public DeleteQuestionResponse deleteQuestion(@RequestPayload DeleteQuestionRequest request) {
        DeleteQuestionResponse response = new DeleteQuestionResponse();
        
        try {
            boolean deleted = questionService.deleteById(request.getId());
            
            if (deleted) {
                response.setSuccess(true);
                response.setMessage("Pregunta eliminada exitosamente");
            } else {
                response.setSuccess(false);
                response.setMessage("Pregunta no encontrada");
            }
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al eliminar la pregunta: " + e.getMessage());
        }
        
        return response;
    }
}