package com.example.soap.repository;

import com.example.soap.entity.AnswerEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AnswerRepository extends JpaRepository<AnswerEntity, Long> {
    
    List<AnswerEntity> findByQuestionId(Long questionId);
    
    List<AnswerEntity> findByUserId(Long userId);
    
    @Query("SELECT a FROM AnswerEntity a JOIN QuestionEntity q ON a.questionId = q.id WHERE a.userId = :userId AND q.surveyId = :surveyId")
    List<AnswerEntity> findByUserIdAndSurveyId(Long userId, Long surveyId);
    
    Optional<AnswerEntity> findByQuestionIdAndUserId(Long questionId, Long userId);
    
    boolean existsByQuestionIdAndUserId(Long questionId, Long userId);
    
    Long countByQuestionId(Long questionId);
}