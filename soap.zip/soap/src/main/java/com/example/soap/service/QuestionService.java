package com.example.soap.service;

import com.example.soap.entity.QuestionEntity;
import com.example.soap.entity.QuestionTypeEnum;
import com.example.soap.generated.*;
import com.example.soap.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.GregorianCalendar;
import java.util.Optional;

@Service
@Transactional
public class QuestionService {
    
    private final QuestionRepository questionRepository;
    
    @Autowired
    public QuestionService(QuestionRepository questionRepository) {
        this.questionRepository = questionRepository;
    }
    
    public Optional<QuestionEntity> findById(Long id) {
        return questionRepository.findById(id);
    }
    
    public java.util.List<QuestionEntity> findBySurveyId(Long surveyId) {
        return questionRepository.findBySurveyIdOrderByIdAsc(surveyId);
    }
    
    public QuestionEntity save(QuestionEntity question) {
        return questionRepository.save(question);
    }
    
    public boolean deleteById(Long id) {
        if (questionRepository.existsById(id)) {
            questionRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    // Métodos de conversión entre entidades y objetos JAXB
    public Question convertToJaxb(QuestionEntity entity) {
        Question question = new Question();
        question.setId(entity.getId());
        question.setSurveyId(entity.getSurveyId());
        question.setText(entity.getText());
        question.setType(convertTypeToJaxb(entity.getType()));
        question.setIsRequired(entity.getIsRequired());
        
        if (entity.getOptions() != null) {
            question.getOptions().addAll(entity.getOptions());
        }
        
        if (entity.getCreatedAt() != null) {
            question.setCreatedAt(convertToXMLGregorianCalendar(entity.getCreatedAt()));
        }
        
        if (entity.getUpdatedAt() != null) {
            question.setUpdatedAt(convertToXMLGregorianCalendar(entity.getUpdatedAt()));
        }
        
        return question;
    }
    
    public QuestionEntity convertToEntity(Question jaxbQuestion) {
        QuestionEntity entity = new QuestionEntity();
        entity.setId(jaxbQuestion.getId());
        entity.setSurveyId(jaxbQuestion.getSurveyId());
        entity.setText(jaxbQuestion.getText());
        entity.setType(convertTypeToEnum(jaxbQuestion.getType()));
        entity.setIsRequired(jaxbQuestion.isIsRequired());
        
        if (!jaxbQuestion.getOptions().isEmpty()) {
            entity.setOptions(jaxbQuestion.getOptions());
        }
        
        return entity;
    }
    
    private QuestionType convertTypeToJaxb(QuestionTypeEnum enumType) {
        return QuestionType.valueOf(enumType.name());
    }
    
    private QuestionTypeEnum convertTypeToEnum(QuestionType jaxbType) {
        return QuestionTypeEnum.valueOf(jaxbType.name());
    }
    
    private XMLGregorianCalendar convertToXMLGregorianCalendar(LocalDateTime localDateTime) {
        try {
            GregorianCalendar gregorianCalendar = GregorianCalendar.from(
                localDateTime.atZone(ZoneId.systemDefault()));
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException("Error converting LocalDateTime to XMLGregorianCalendar", e);
        }
    }
}