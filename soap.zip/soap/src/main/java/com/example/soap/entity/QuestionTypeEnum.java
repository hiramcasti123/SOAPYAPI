package com.example.soap.entity;

public enum QuestionTypeEnum {
    TEXT,
    MULTIPLE_CHOICE,
    SINGLE_CHOICE,
    RATING
}