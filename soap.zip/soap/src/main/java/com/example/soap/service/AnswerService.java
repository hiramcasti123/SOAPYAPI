package com.example.soap.service;

import com.example.soap.entity.AnswerEntity;
import com.example.soap.generated.Answer;
import com.example.soap.repository.AnswerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.GregorianCalendar;
import java.util.Optional;

@Service
@Transactional
public class AnswerService {
    
    private final AnswerRepository answerRepository;
    
    @Autowired
    public AnswerService(AnswerRepository answerRepository) {
        this.answerRepository = answerRepository;
    }
    
    public Optional<AnswerEntity> findById(Long id) {
        return answerRepository.findById(id);
    }
    
    public java.util.List<AnswerEntity> findByQuestionId(Long questionId) {
        return answerRepository.findByQuestionId(questionId);
    }
    
    public java.util.List<AnswerEntity> findByUserId(Long userId) {
        return answerRepository.findByUserId(userId);
    }
    
    public java.util.List<AnswerEntity> findByUserIdAndSurveyId(Long userId, Long surveyId) {
        return answerRepository.findByUserIdAndSurveyId(userId, surveyId);
    }
    
    public AnswerEntity save(AnswerEntity answer) {
        return answerRepository.save(answer);
    }
    
    public boolean deleteById(Long id) {
        if (answerRepository.existsById(id)) {
            answerRepository.deleteById(id);
            return true;
        }
        return false;
    }
    
    // Métodos de conversión entre entidades y objetos JAXB
    public Answer convertToJaxb(AnswerEntity entity) {
        Answer answer = new Answer();
        answer.setId(entity.getId());
        answer.setQuestionId(entity.getQuestionId());
        answer.setUserId(entity.getUserId());
        answer.setAnswerText(entity.getAnswerText());
        answer.setSelectedOption(entity.getSelectedOption());
        answer.setRating(entity.getRating());
        
        if (entity.getSubmittedAt() != null) {
            answer.setSubmittedAt(convertToXMLGregorianCalendar(entity.getSubmittedAt()));
        }
        
        return answer;
    }
    
    public AnswerEntity convertToEntity(Answer jaxbAnswer) {
        AnswerEntity entity = new AnswerEntity();
        entity.setId(jaxbAnswer.getId());
        entity.setQuestionId(jaxbAnswer.getQuestionId());
        entity.setUserId(jaxbAnswer.getUserId());
        entity.setAnswerText(jaxbAnswer.getAnswerText());
        entity.setSelectedOption(jaxbAnswer.getSelectedOption());
        entity.setRating(jaxbAnswer.getRating());
        
        return entity;
    }
    
    private XMLGregorianCalendar convertToXMLGregorianCalendar(LocalDateTime localDateTime) {
        try {
            GregorianCalendar gregorianCalendar = GregorianCalendar.from(
                localDateTime.atZone(ZoneId.systemDefault()));
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
        } catch (DatatypeConfigurationException e) {
            throw new RuntimeException("Error converting LocalDateTime to XMLGregorianCalendar", e);
        }
    }
}