package com.example.soap.repository;

import com.example.soap.entity.QuestionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QuestionRepository extends JpaRepository<QuestionEntity, Long> {
    
    List<QuestionEntity> findBySurveyId(Long surveyId);
    
    List<QuestionEntity> findBySurveyIdOrderByIdAsc(Long surveyId);
    
    boolean existsBySurveyId(Long surveyId);
    
    Long countBySurveyId(Long surveyId);
}