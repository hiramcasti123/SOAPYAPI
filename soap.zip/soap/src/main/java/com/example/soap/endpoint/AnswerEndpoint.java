package com.example.soap.endpoint;

import com.example.soap.entity.AnswerEntity;
import com.example.soap.generated.*;
import com.example.soap.service.AnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import java.util.Optional;

@Endpoint
public class AnswerEndpoint {
    
    private static final String NAMESPACE_URI = "http://soap.example.com/survey";
    
    private final AnswerService answerService;
    
    @Autowired
    public AnswerEndpoint(AnswerService answerService) {
        this.answerService = answerService;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAnswerRequest")
    @ResponsePayload
    public GetAnswerResponse getAnswer(@RequestPayload GetAnswerRequest request) {
        GetAnswerResponse response = new GetAnswerResponse();
        
        Optional<AnswerEntity> answerOpt = answerService.findById(request.getId());
        if (answerOpt.isPresent()) {
            Answer answer = answerService.convertToJaxb(answerOpt.get());
            response.setAnswer(answer);
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAnswersByQuestionRequest")
    @ResponsePayload
    public GetAnswersByQuestionResponse getAnswersByQuestion(@RequestPayload GetAnswersByQuestionRequest request) {
        GetAnswersByQuestionResponse response = new GetAnswersByQuestionResponse();
        
        java.util.List<AnswerEntity> answers = answerService.findByQuestionId(request.getQuestionId());
        for (AnswerEntity entity : answers) {
            Answer answer = answerService.convertToJaxb(entity);
            response.getAnswers().add(answer);
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getAnswersByUserRequest")
    @ResponsePayload
    public GetAnswersByUserResponse getAnswersByUser(@RequestPayload GetAnswersByUserRequest request) {
        GetAnswersByUserResponse response = new GetAnswersByUserResponse();
        
        java.util.List<AnswerEntity> answers;
        if (request.getSurveyId() != null) {
            answers = answerService.findByUserIdAndSurveyId(request.getUserId(), request.getSurveyId());
        } else {
            answers = answerService.findByUserId(request.getUserId());
        }
        
        for (AnswerEntity entity : answers) {
            Answer answer = answerService.convertToJaxb(entity);
            response.getAnswers().add(answer);
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "addAnswerRequest")
    @ResponsePayload
    public AddAnswerResponse addAnswer(@RequestPayload AddAnswerRequest request) {
        AddAnswerResponse response = new AddAnswerResponse();
        
        try {
            AnswerEntity entity = answerService.convertToEntity(request.getAnswer());
            AnswerEntity savedEntity = answerService.save(entity);
            
            Answer savedAnswer = answerService.convertToJaxb(savedEntity);
            response.setAnswer(savedAnswer);
            response.setSuccess(true);
            response.setMessage("Respuesta guardada exitosamente");
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al guardar la respuesta: " + e.getMessage());
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "updateAnswerRequest")
    @ResponsePayload
    public UpdateAnswerResponse updateAnswer(@RequestPayload UpdateAnswerRequest request) {
        UpdateAnswerResponse response = new UpdateAnswerResponse();
        
        try {
            AnswerEntity entity = answerService.convertToEntity(request.getAnswer());
            
            if (entity.getId() == null || !answerService.findById(entity.getId()).isPresent()) {
                response.setSuccess(false);
                response.setMessage("Respuesta no encontrada");
                return response;
            }
            
            AnswerEntity savedEntity = answerService.save(entity);
            Answer savedAnswer = answerService.convertToJaxb(savedEntity);
            
            response.setAnswer(savedAnswer);
            response.setSuccess(true);
            response.setMessage("Respuesta actualizada exitosamente");
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al actualizar la respuesta: " + e.getMessage());
        }
        
        return response;
    }
    
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "deleteAnswerRequest")
    @ResponsePayload
    public DeleteAnswerResponse deleteAnswer(@RequestPayload DeleteAnswerRequest request) {
        DeleteAnswerResponse response = new DeleteAnswerResponse();
        
        try {
            boolean deleted = answerService.deleteById(request.getId());
            
            if (deleted) {
                response.setSuccess(true);
                response.setMessage("Respuesta eliminada exitosamente");
            } else {
                response.setSuccess(false);
                response.setMessage("Respuesta no encontrada");
            }
        } catch (Exception e) {
            response.setSuccess(false);
            response.setMessage("Error al eliminar la respuesta: " + e.getMessage());
        }
        
        return response;
    }
}