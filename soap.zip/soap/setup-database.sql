-- Script SQL para configurar la base de datos MySQL
-- Ejecutar antes de iniciar la aplicación

-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS survey_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usar la base de datos
USE survey_db;

-- Crear usuario específico para la aplicación (opcional pero recomendado)
-- NOTA: Ajusta el password según tus necesidades de seguridad
CREATE USER IF NOT EXISTS 'survey_user'@'localhost' IDENTIFIED BY 'survey_password123';
GRANT ALL PRIVILEGES ON survey_db.* TO 'survey_user'@'localhost';

-- Opcional: Si quieres usar el usuario root, simplemente asegúrate de que tiene password
-- ALTER USER 'root'@'localhost' IDENTIFIED BY 'tu_password_aqui';

FLUSH PRIVILEGES;

-- Las tablas se crearán automáticamente por Hibernate cuando inicies la aplicación
-- Pero si quieres crearlas manualmente, aquí están los scripts:

/*
-- Tabla de preguntas
CREATE TABLE IF NOT EXISTS questions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    survey_id BIGINT NOT NULL,
    text TEXT NOT NULL,
    type ENUM('TEXT', 'MULTIPLE_CHOICE', 'SINGLE_CHOICE', 'RATING') NOT NULL,
    is_required BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla de opciones de preguntas (para preguntas de selección múltiple)
CREATE TABLE IF NOT EXISTS question_options (
    question_id BIGINT NOT NULL,
    option_text VARCHAR(500) NOT NULL,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- Tabla de respuestas
CREATE TABLE IF NOT EXISTS answers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    question_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    answer_text TEXT,
    selected_option VARCHAR(500),
    rating INT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
);

-- Índices para mejor rendimiento
CREATE INDEX IF NOT EXISTS idx_questions_survey_id ON questions(survey_id);
CREATE INDEX IF NOT EXISTS idx_answers_question_id ON answers(question_id);
CREATE INDEX IF NOT EXISTS idx_answers_user_id ON answers(user_id);
*/

-- Datos de ejemplo (opcional)
/*
-- Insertar preguntas de ejemplo
INSERT INTO questions (survey_id, text, type, is_required) VALUES
(1, '¿Cuál es tu color favorito?', 'MULTIPLE_CHOICE', true),
(1, '¿Qué opinas sobre nuestro servicio?', 'TEXT', true),
(1, '¿Cómo calificarías nuestro producto del 1 al 10?', 'RATING', true);

-- Insertar opciones para la pregunta de selección múltiple (ID = 1)
INSERT INTO question_options (question_id, option_text) VALUES
(1, 'Rojo'),
(1, 'Azul'),
(1, 'Verde'),
(1, 'Amarillo');

-- Insertar respuestas de ejemplo
INSERT INTO answers (question_id, user_id, selected_option) VALUES
(1, 100, 'Azul');

INSERT INTO answers (question_id, user_id, answer_text) VALUES
(2, 100, 'El servicio es excelente y muy rápido');

INSERT INTO answers (question_id, user_id, rating) VALUES
(3, 100, 9);
*/

-- Verificar que todo esté correcto
SELECT 'Base de datos survey_db configurada correctamente' as resultado;